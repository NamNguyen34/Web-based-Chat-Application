package uta.cse.cse3310.webchat;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public class Logger {
    private int numberOfLogs = 0;
    private String filePath = "Log.txt";

    public int getNumberOfLogs() {
        return numberOfLogs;
    }

    Logger(String filePath) {
        this.filePath = filePath;
    }

    Logger() {
    }

    public void saveToLog(String message, boolean isSent) {
        try {
            // Read the existing content of the file, if any
            List<JsonElement> logs = new ArrayList<>();
            if (Files.exists(Paths.get(filePath))) {
                String content = new String(Files.readAllBytes(Paths.get(filePath)));
                if (!content.isEmpty()) {
                    JsonArray jsonArray = new Gson().fromJson(content, JsonArray.class);
                    for (JsonElement jsonElement : jsonArray) {
                        logs.add(jsonElement);
                    }
                }
            }

            // Create a new JSON object for the current log entry
            JsonObject jsonLog = new JsonObject();
            jsonLog.addProperty("message", message);
            jsonLog.addProperty("MessageType", isSent ? "Sent" : "Received");

            LocalDateTime currentTime = LocalDateTime.now();

            // Define the desired date-time format using DateTimeFormatter
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

            // Format the LocalDateTime object to a string
            String timestamp = currentTime.format(formatter);

            // Print the timestamp string

            jsonLog.addProperty("timestamp", timestamp);

            // Add the new log entry to the existing list of logs
            logs.add(jsonLog);

            // Convert the list of logs to a JSON array
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            JsonArray jsonArray = new JsonArray();
            for (JsonElement log : logs) {
                jsonArray.add(log);
            }

            // Write the JSON array to the file
            try (FileWriter fw = new FileWriter(filePath)) {
                fw.write(gson.toJson(jsonArray));
                numberOfLogs++;
            } catch (IOException e) {
                System.out.println("Error writing to log file");
            }
        } catch (Exception e) {
            System.out.println("Error creating JSON object");
        }
    }
}
