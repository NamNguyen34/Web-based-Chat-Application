package uta.cse.cse3310.webchat;

import org.java_websocket.WebSocket;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.Vector;

public class ChatRoom {
    public String Name;
    public Vector<User> users;
    public Logger logger;
    public int numberOfSentMessages = 0;

    public ChatRoom() {
        users = new Vector<>();
    }

    public ChatRoom(String N) {
        Name = N;
        users = new Vector<>();
    }

    public void addUser(User U) {
        users.add(U);
    }

    public void removeUser(User U) {
        users.remove(U);
    }

    public void broadcast(String message) {
        // for (WebSocket user : users) {
        // user.send(message);
        // }
        logger.saveToLog(message, true);
    }

    public boolean isUserInRoom(User U) {
        for (int i = 0; i < users.size(); i++) {
            if (users.get(i).ID == U.ID) {
                return true;
            }
        }
        return false;
    }

    public void sendToAllFromUser(User CurrentUser, SendChatMessage U) {
        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();
        System.out.println("\twe are in chatroom " + this.Name);

        for (User userToSend : this.users) {
            if (userToSend.isIgnored(CurrentUser) || CurrentUser.isIgnored(userToSend)) {
                System.out.println("\t\tignore the message for chatroom " + this.Name + " from user "
                        + CurrentUser.Name + " to user " + userToSend.Name);
                continue;
            }
            System.out.println("\t\tsend the message for chatroom " + this.Name + " from user "
                    + CurrentUser.Name + " to user " + userToSend.Name);
            SendChatMessage S = new SendChatMessage();

            S.IsMe = userToSend.ID == CurrentUser.ID;
            S.Text = U.Text;
            S.From = CurrentUser.Name;
            String jsonString = gson.toJson(S);

            WebSocket otherUser = userToSend.conn;

            System.out.println("other User: " + otherUser);
            if (otherUser != null) {
                try {
                    otherUser.send(jsonString);
                    logger.saveToLog(jsonString, true);
                } catch (Exception e) {
                    System.out.println("Exception in handleSendingMessage");
                }
            } else {
                System.out.println("otherUser is null");
            }
        }
        numberOfSentMessages++;
    }

    public String toJString() {
        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();
       // only jsony the name and the number of users
        ChatRoomDetails CRD = new ChatRoomDetails(this);
        String jsonString = gson.toJson(CRD);
        return jsonString;
        
    }
}
