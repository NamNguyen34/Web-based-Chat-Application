package uta.cse.cse3310.webchat;

public class SendChatMessage {
    public String From;
    public String Text;
    public boolean IsMe = false;
}
