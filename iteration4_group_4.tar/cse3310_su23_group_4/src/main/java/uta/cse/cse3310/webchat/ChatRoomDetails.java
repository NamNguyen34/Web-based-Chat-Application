package uta.cse.cse3310.webchat;

public class ChatRoomDetails {
    public int NumberOfSentMessages;
    public String Name;

    ChatRoomDetails(ChatRoom chatRoom) {
        this.NumberOfSentMessages = chatRoom.numberOfSentMessages;
        this.Name = chatRoom.Name;
    }
}
