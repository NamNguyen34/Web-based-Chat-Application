package uta.cse.cse3310.webchat;

public class LoginMessage {
   public String Name;
}
