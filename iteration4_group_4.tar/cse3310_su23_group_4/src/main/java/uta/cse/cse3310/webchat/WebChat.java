package uta.cse.cse3310.webchat;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.Vector;

import org.java_websocket.drafts.Draft;
import org.java_websocket.WebSocket;
import org.java_websocket.drafts.Draft_6455;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class WebChat extends WebSocketServer {

    // All users connected at this time
    // Vector<User> Users = new Vector<User>();
    UserList Users = new UserList();
    Logger logger = new Logger();

    // All chatRooms that exist at this time
    Vector<ChatRoom> ActiveRooms = new Vector<ChatRoom>();

    public WebChat(int port) throws UnknownHostException {
        super(new InetSocketAddress(port));
    }

    public WebChat(InetSocketAddress address) {
        super(address);
    }

    public WebChat(int port, Draft_6455 draft) {
        super(new InetSocketAddress(port), Collections.<Draft>singletonList(draft));
    }

    @Override
    public void onOpen(WebSocket conn, ClientHandshake handshake) {

        // conn.send("Welcome to the server!");

        System.out.println(conn); // Prints the statement to stdout to indicate a new connection has opened

        // This is the first time we have seen this client.
        // So, we need to make an instance of a User class
        User U = new User(conn.getRemoteSocketAddress().toString(), conn);

        // And add it to the list of users
        Users.add(U);

        // And we need to add it to the 'lobby', because it has to be somewhere.
        // (at this point, maybe a vector was not the ideal data structure...)
        Integer found = -1;
        for (Integer i = 0; i < ActiveRooms.size(); i++) {
            if (ActiveRooms.get(i).Name == "lobby") {
                found = i;
            }
            System.out.print(ActiveRooms.get(i).Name + " ");
        }
        // Add this new user to the lobby
        ActiveRooms.get(found).addUser(U);

        // Next, we send the information that is needed by the client web page.
        // At this time we don't know the users name or anything, but we can tell
        // the user all the other users and all the chatrooms that are available.
        RecvChatMessage InitMessage = new RecvChatMessage();
        for (Integer i = 0; i < Users.size(); i++) {
            InitMessage.Users.add(Users.get(i).toJString());
        }
        for (Integer i = 0; i < ActiveRooms.size(); i++) {
            InitMessage.Chatrooms.add(ActiveRooms.get(i).toJString());
        }

        // Turn it into json
        Gson gson = new Gson();
        String jsonString = gson.toJson(InitMessage);
        System.out.println("Sending " + jsonString);

        conn.send(jsonString);
        // This is where it should be logged.
        logger.saveToLog(jsonString, true);
    }

    @Override
    public void onClose(WebSocket conn, int code, String reason, boolean remote) {
        User user = Users.conn2user(conn);
        broadcast(user.Name + " has left the room!");
        logger.saveToLog(user.Name + " has left the room!", true);
        System.out.println(user.Name + " has left the room!");
        Users.del(conn);
        conn.close();
    }

    @Override
    public void onMessage(WebSocket conn, String message) {
        // Allows onMessage to receive contents from the Message class to print to
        // stdout and to transmit the message to the chat room
        System.out.println(Users.conn2Id(conn) + ": " + message);

        // Here is the place to log the messages coming in
        logger.saveToLog(message, false);

        // Process the message
        //
        // This is a brute force solution. There are many better ways to do it!
        //
        if (message.contains("\"Type\":\"Login\"")) {
            handleUserLogin(conn, message);
        } else if (message.contains("\"Type\":\"Chatroom\"")) {
            handleCreatingNewChatroom(conn, message);
        } else if (message.contains("\"Type\":\"Text\"")) {
            handleSendingMessage(conn, message);
        } else if (message.contains("\"Type\":\"BlockUser\"")) {
            handleBlockingUser(conn, message);
        }

        // Next, we send the information that is needed by the client web page.
        // At this time we don't know the users name or anything, but we can tell
        // the user all the other users and all the chatrooms that are available.
        handleGeneralDataBroadcast();

    }

    public void handleGeneralDataBroadcast() {
        RecvChatMessage InitMessage = new RecvChatMessage();
        Gson gson = new Gson();
        for (Integer i = 0; i < Users.size(); i++) {
            InitMessage.Users.add(Users.get(i).toJString());
        }
        for (Integer i = 0; i < ActiveRooms.size(); i++) {
            InitMessage.Chatrooms.add(ActiveRooms.get(i).toJString());
        }

        // Turn it into json
        String jsonString = gson.toJson(InitMessage);
        System.out.println("Sending " + jsonString);

        broadcast(jsonString);
        // This is where it should be logged.
        logger.saveToLog(jsonString, true);
    }

    public void handleUserLogin(WebSocket conn, String message) {
        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();
        LoginMessage U = gson.fromJson(message, LoginMessage.class);
        System.out.println("Got a login message");
        // for now, all we have to do is put it in the list of users.
        Users.InsertNameForConn(conn, U.Name);
    }

    public void handleCreatingNewChatroom(WebSocket conn, String message) {
        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();
        SelectChatMessage U = gson.fromJson(message, SelectChatMessage.class);
        System.out.println("Got a chatroom message");

        // A user can be in 1 and only 1 chatroom. So, before we start, let's
        // delete the user from the chatroom it is currently in.
        String theUserName = Users.conn2name(conn);

        for (Integer i = 0; i < ActiveRooms.size(); i++) {
            for (Integer j = 0; j < ActiveRooms.get(i).users.size(); j++) {
                if (theUserName.equals(ActiveRooms.get(i).users.get(j).Name)) {
                    ActiveRooms.get(i).users.remove(ActiveRooms.get(i).users.get(j));
                    break;
                }
            }
        }

        Integer found = -1;
        for (Integer i = 0; i < ActiveRooms.size(); i++) {
            if (ActiveRooms.get(i).Name.equals(U.Name)) {
                found = i;
            }
        }
        // it does not exist, so make it.
        if (found == -1) {
            ActiveRooms.add(new ChatRoom(U.Name));
            System.out.println("create a chatroom named " + U.Name + " completed");
        }

        // lets look again, in case we added to it.
        found = -1;
        for (Integer i = 0; i < ActiveRooms.size(); i++) {
            if (ActiveRooms.get(i).Name.equals(U.Name)) {
                found = i;
            }
        }
        // found is the chatroom where we need to be.
        // so, let's go put the User in that chatroom
        // Need to find the User instance, so we can add it to the chatroom
        // all we have is a 'conn' object when this routine is called
        // Add them now
        ActiveRooms.get(found).users.add(Users.conn2user(conn));
    }

    public void handleBlockingUser(WebSocket conn, String message) {
        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();
        BlockUserMessage U = gson.fromJson(message, BlockUserMessage.class);
        System.out.println("Got a block user message");
        User CurrentUser = Users.conn2user(conn);

        User BlockedUser = Users.getUserFromNameOrId(U.Text);
        if (BlockedUser != null) {
            CurrentUser.addIgnore(BlockedUser);
            System.out.println("User " + CurrentUser.Name + " blocked user " + BlockedUser.Name);
        } else {
            AlertMessage alert = new AlertMessage();
            alert.Text = "User " + U.Text + " does not exist.";
            conn.send(gson.toJson(alert));
            logger.saveToLog(gson.toJson(alert), true);
            System.out.println("User " + U.Text + " does not exist.");
        }
    }

    public void handleSendingMessage(WebSocket conn, String message) {
        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();
        SendChatMessage U = gson.fromJson(message, SendChatMessage.class);

        // Identify the current user
        User CurrentUser = Users.conn2user(conn);

        // Search for the chatroom the current user is in
        ChatRoom userChatRoom = null;
        for (ChatRoom CR : ActiveRooms) {
            if (CR.isUserInRoom(CurrentUser)) {
                userChatRoom = CR;
                break; // Found the chatroom, no need to continue searching
            }
        }

        // Handle messaging within the found chatroom
        if (userChatRoom != null) {
           userChatRoom.sendToAllFromUser(CurrentUser, U);

        } else {
            System.out.println("couldn't find the chatroom");
        }
    }

    @Override
    public void onMessage(WebSocket conn, ByteBuffer message) {
        broadcast(message.array());
        logger.saveToLog(message.toString(), false);
        System.out.println(Users.conn2Id(conn) + ": " + message);
    }

    @Override
    public void onError(WebSocket conn, Exception ex) {
        ex.printStackTrace();
        if (conn != null) {
        }
    }

    @Override
    public void onStart() {

        // There must be at least 1 chatroom to start out with,
        // let's call it the 'lobby'...
        ChatRoom Lobby = new ChatRoom("lobby");
        ActiveRooms.add(Lobby);

        System.out.println("Server started!");
        setConnectionLostTimeout(0);
        setConnectionLostTimeout(100);
    }

    public static void main(String[] args) throws IOException {

        // 8086/8087
        int hport = 8086;
        HttpServer H = new HttpServer(hport, "./html");
        H.start();
        System.out.println("HTTP Server started on port " + hport);

        int wport = 8087;
        WebChat w = new WebChat(wport);
        w.start();
        System.out.println("WebChat server started on port: " + w.getPort());
        Runtime.getRuntime().addShutdownHook(new Thread() {
            public void run() {
                System.out.println("Shutting down...");
                try {
                    w.stop();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
    }

}
