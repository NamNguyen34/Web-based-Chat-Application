package uta.cse.cse3310.webchat;

public class UserDetails {

    public int ID;
    public String Name;
    public String TimeBeenActive;
}
