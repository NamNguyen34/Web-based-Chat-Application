package uta.cse.cse3310.webchat;

public class BlockUserMessage {
    public String Type;
    public String Text;

}
