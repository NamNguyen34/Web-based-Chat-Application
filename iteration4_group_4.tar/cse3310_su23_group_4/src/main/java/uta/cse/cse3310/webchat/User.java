package uta.cse.cse3310.webchat;

import java.util.Vector;

import org.java_websocket.WebSocket;

import com.google.gson.Gson;

public class User {
    public static int NextID = 1;
    String Name;
    public int ID = NextID++;
    // a conn is needed to be able to know where to send the messages
    public WebSocket conn;
    // vector to save ignore list
    public Vector<User> ignoreList = new Vector<User>();

    // timestamp for login time
    public long loginTime;

    public User(String N) {
        Name = N;
        conn = null;
        loginTime = System.currentTimeMillis();

    }

    public User(String N, WebSocket C) {
        Name = N;
        conn = C;
        loginTime = System.currentTimeMillis();
    }

    public User(WebSocket C) {
        conn = C;
        Name = "";
        loginTime = System.currentTimeMillis();
    }

    public boolean isIgnored(User N) {
        if (N == null) {
            return false;
        }
        for (int i = 0; i < ignoreList.size(); i++) {
            if (ignoreList.get(i).ID == N.ID) {
                return true;
            }
        }
        return false;
    }

    public void addIgnore(User N) {
        if (N.ID != this.ID) {
            ignoreList.add(N);
        }
    }

    public int getIgnoreListSize() {
        return ignoreList.size();
    }

    public String toJString() {
        long currentTime = System.currentTimeMillis();

        // Elapsed time in milliseconds
        long elapsedTime = currentTime - loginTime;
        int seconds = (int) (elapsedTime / 1000) % 60;
        int minutes = (int) (elapsedTime / (1000 * 60)) % 60;
        int hours = (int) (elapsedTime / (1000 * 60 * 60)) % 24;
        String elapsed = String.format("%02d:%02d:%02d", hours, minutes, seconds);

        // Example: "01:45:32"
        Gson gson = new Gson();
        UserDetails UserDetails = new UserDetails();
        UserDetails.Name = Name;
        UserDetails.TimeBeenActive = elapsed;
        UserDetails.ID = ID;
        return gson.toJson(UserDetails);
    }
}
