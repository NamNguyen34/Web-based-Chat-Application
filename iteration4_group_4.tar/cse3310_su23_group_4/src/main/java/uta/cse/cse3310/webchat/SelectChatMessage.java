package uta.cse.cse3310.webchat;

public class SelectChatMessage {
     public String Name;
}
