package uta.cse.cse3310.webchat;

import java.util.Vector;

import org.java_websocket.WebSocket;

public class UserList {

  // All users connected at this time
  private Vector<User> Users = new Vector<User>();

  public void add(User U) {
    Users.add(U);
  }

  public User get(Integer I) {
    return Users.get(I);
  }

  public Integer size() {
    return Users.size();
  }

  public void del(WebSocket conn) {
    for (int i = 0; i < Users.size(); i++) {
      if (Users.get(i).conn == conn) {
        Users.remove(i);
      }
    }
    User user = this.conn2user(conn);
    Users.remove(user);
  }

  public void InsertNameForConn(WebSocket conn, String name) {
    // It is a vector, so we search it all

    boolean userFound = false;
    for (Integer i = 0; i < Users.size(); i++) {
      if (Users.get(i).conn == conn) {
        Users.get(i).Name = name;
        userFound = true;
      }
    }
    if (!userFound) {
      // if the user is not found, we add it
      User U = new User(name, conn);
      Users.add(U);
    }

  }

  public User conn2user(WebSocket conn) {
    // given a conn, return the user instance
    for (Integer i = 0; i < Users.size(); i++) {
      if (conn == Users.get(i).conn) {
        return Users.get(i);
      }
    }
    return null;
  }

  public String conn2name(WebSocket conn) {
    for (Integer i = 0; i < Users.size(); i++) {
      if (conn == Users.get(i).conn) {
        return Users.get(i).Name;
      }
    }
    return "not found";
  }

  public WebSocket name2conn(String n) {
    for (Integer i = 0; i < Users.size(); i++) {
      if (n == Users.get(i).Name) {
        return Users.get(i).conn;
      }
    }
    return null;
  }

  public User name2user(String n) {
    for (Integer i = 0; i < Users.size(); i++) {
      if (Users.get(i).Name.equalsIgnoreCase(n)) {
        return Users.get(i);
      }
      System.out.println("name2user: " + n + " " + Users.get(i).Name);
    }
    return null;
  }

  public User getUserFromNameOrId(String n) {
    // can n be converted to an integer?
    try {
      Integer id = Integer.parseInt(n);
      return idToUser(id);

    } catch (NumberFormatException e) {
      // n is not an integer
      return name2user(n);
    }
  }

  private User idToUser(Integer id) {
    for (Integer i = 0; i < Users.size(); i++) {
      if (Users.get(i).ID == id) {
        return Users.get(i);
      }
    }
    return null;
  }
  public int conn2Id(WebSocket conn) {
    for (Integer i = 0; i < Users.size(); i++) {
      if (conn == Users.get(i).conn) {
        return Users.get(i).ID;
      }
    }
    return -1;
  }
  public final Vector<User> getUsers() {
    return Users;
  }
}
