package uta.cse.cse3310.webchat;

public class AlertMessage {
    public String Type = "Alert";
    public String Text = "";
}
