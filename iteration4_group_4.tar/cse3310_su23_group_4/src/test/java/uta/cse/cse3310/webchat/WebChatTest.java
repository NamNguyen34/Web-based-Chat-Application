package uta.cse.cse3310.webchat;

import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.util.Vector;

import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.junit.jupiter.api.*;

public class WebChatTest {

    WebChat chat;
    WebSocket webSocketMock;

    @BeforeEach
    public void setup() throws UnknownHostException {
        chat = new WebChat(8087);
        webSocketMock = Mockito.mock(WebSocket.class);
        // Create a mock SocketAddress
        // Create a mock InetSocketAddress
        InetSocketAddress inetSocketAddressMock = new InetSocketAddress("localhost", 8086);
        // Stub the getRemoteSocketAddress() method to return the mock InetSocketAddress
        when(webSocketMock.getRemoteSocketAddress()).thenReturn(inetSocketAddressMock);

    }

    @Test
    public void testOnMessage_loginMessage() throws UnknownHostException {
        chat = new WebChat(8087);
        webSocketMock = Mockito.mock(WebSocket.class);
        // Create a mock SocketAddress
        // Create a mock InetSocketAddress
        InetSocketAddress inetSocketAddressMock = new InetSocketAddress("localhost", 8086);
        // Stub the getRemoteSocketAddress() method to return the mock InetSocketAddress
        when(webSocketMock.getRemoteSocketAddress()).thenReturn(inetSocketAddressMock);

        String loginMessage = "{\"Type\":\"Login\", \"Name\":\"test\"}";

        // Run the method we are testing
        chat.onMessage(webSocketMock, loginMessage);

        // Verify the user is added after a login message
        assertEquals(new Integer(1), chat.Users.size());
        assertEquals("test", chat.Users.get(0).Name);
    }

    @Test
    public void testOnMessage_chatroomMessage() {
        // Create a mock WebSocket connection
        WebSocket conn = Mockito.mock(WebSocket.class);

        // Define a chatroom message
        String chatroomMessage = "{\"Type\":\"Chatroom\", \"Name\":\"new chat room\"}";

        // Call the onMessage method
        chat.onMessage(conn, chatroomMessage);

        // Retrieve the active rooms from the server
        // This assumes that your WebSocketServer class has a 'getActiveRooms' method
        Vector<ChatRoom> activeRooms = chat.ActiveRooms;

        // Check that the new room has been created
        boolean roomCreated = false;
        for (ChatRoom room : activeRooms) {
            if (room.Name.equals("new chat room")) {
                roomCreated = true;
                break;
            }
        }

        assertTrue(roomCreated);
    }

    @Test
    public void testOnOpen() {
        ClientHandshake handshakeMock = Mockito.mock(ClientHandshake.class);
        // Call the onOpen method
        chat.onStart();
        chat.onOpen(webSocketMock, handshakeMock);

        // Check if a user is added
        assertFalse(chat.Users.size() == 0, "Users list should not be empty after connection is opened");

        // Check if lobby room is created
        boolean lobbyCreated = false;
        for (ChatRoom room : chat.ActiveRooms) {
            if (room.Name.equals("lobby")) {
                lobbyCreated = true;
                break;
            }
        }
        assertTrue(lobbyCreated, "A chatroom named 'lobby' should be created on open");
    }

    @Test
    public void testOnMessage_createNonoChatroom() {
        // Mock the WebSocket connection
        WebSocket conn = Mockito.mock(WebSocket.class);

        // Define the chatroom creation message
        String chatroomCreationMessage = "{\"Type\":\"Chatroom\", \"Name\":\"nono\"}";

        // Call the onMessage method
        chat.onMessage(conn, chatroomCreationMessage);

        // Retrieve the active rooms from the server
        Vector<ChatRoom> activeRooms = chat.ActiveRooms;

        // Check if the "nono" chatroom has been created
        boolean nonoRoomCreated = false;
        for (ChatRoom room : activeRooms) {
            if (room.Name.equals("nono")) {
                nonoRoomCreated = true;
                break;
            }
        }

        assertTrue(nonoRoomCreated, "A chatroom named 'nono' should be created");
    }

    @Test
    public void testOnMessage_blockUserUsingName() {
        // Create a mock WebSocket connection for user1
        WebSocket user1Conn = Mockito.mock(WebSocket.class);
        // Stub the getRemoteSocketAddress() method to return the mock InetSocketAddress
        when(user1Conn.getRemoteSocketAddress()).thenReturn(new InetSocketAddress("localhost", 8086));
        // Let's simulate user1's login to initialize the user
        chat.onMessage(user1Conn, "{\"Type\":\"Login\", \"Name\":\"user1\"}");

        // Create another mock WebSocket connection for user2
        WebSocket user2Conn = Mockito.mock(WebSocket.class);
        when(user2Conn.getRemoteSocketAddress()).thenReturn(new InetSocketAddress("localhost", 8087));
        // Let's simulate user2's login
        chat.onMessage(user2Conn, "{\"Type\":\"Login\", \"Name\":\"user2\"}");

        // Let's have user1 block user2
        chat.onMessage(user1Conn, "{\"Type\":\"BlockUser\",\"Text\":\"user2\"}");

        // Fetch user1 from the server's user list
        User user1 = chat.Users.name2user("user1");
        assertEquals(2, chat.Users.size(), "There should be 2 users in the server's user list");

        assertNotNull(user1, "User1 should not be null");

        assertEquals(1, user1.getIgnoreListSize(), "User1 should have 1 user in their ignore list");
        // Check if user2 is in user1's ignoreList
        boolean isBlocked = user1.isIgnored(chat.Users.name2user("user2"));

        assertTrue(isBlocked, "User2 should be in User1's ignore list after the block action");
    }

    @Test
    public void testOnMessage_blockUserUsingUserID() {
        // Create a mock WebSocket connection for user1
        WebSocket user1Conn = Mockito.mock(WebSocket.class);
        // Stub the getRemoteSocketAddress() method to return the mock InetSocketAddress
        when(user1Conn.getRemoteSocketAddress()).thenReturn(new InetSocketAddress("localhost", 8086));
        // Let's simulate user1's login to initialize the user
        chat.onMessage(user1Conn, "{\"Type\":\"Login\", \"Name\":\"user1\"}");

        // Create another mock WebSocket connection for user2
        WebSocket user2Conn = Mockito.mock(WebSocket.class);
        when(user2Conn.getRemoteSocketAddress()).thenReturn(new InetSocketAddress("localhost", 8087));
        // Let's simulate user2's login
        chat.onMessage(user2Conn, "{\"Type\":\"Login\", \"Name\":\"user2\"}");

        // Let's have user1 block user2
        int user2Id = chat.Users.name2user("user2").ID;
        chat.onMessage(user1Conn, "{\"Type\":\"BlockUser\",\"Text\":\"" + user2Id + "\"}");

        // Fetch user1 from the server's user list
        User user1 = chat.Users.name2user("user1");
        assertEquals(2, chat.Users.size(), "There should be 2 users in the server's user list");

        assertNotNull(user1, "User1 should not be null");

        assertEquals(1, user1.getIgnoreListSize(), "User1 should have 1 user in their ignore list");
        // Check if user2 is in user1's ignoreList
        boolean isBlocked = user1.isIgnored(chat.Users.name2user("user2"));

        assertTrue(isBlocked, "User2 should be in User1's ignore list after the block action");
    }
}
