package uta.cse.cse3310.webchat;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import org.junit.jupiter.api.Test;

public class LoggerTest {
    private Logger logger;
    private final String filePath = "logTest.txt";

    @BeforeEach
    public void setup() {
        logger = new Logger(filePath);
    }

    @AfterEach
    public void tearDown() {
        File logFile = new File(filePath);
        if (logFile.exists()) {
            logFile.delete();
        }
    }

    @Test
    public void testSaveToLog() throws IOException {
        logger = new Logger(filePath);
        String logMessage = "Test log message";
        logger.saveToLog(logMessage, true);
        String content = new String(Files.readAllBytes(Paths.get(filePath)));
        assertTrue(content.contains(logMessage));
        assertEquals(1, logger.getNumberOfLogs());
    }

    @Test
    public void testGetNumberOfLogs() {
        logger = new Logger(filePath);
        logger.saveToLog("Test log message 1", false);
        logger.saveToLog("Test log message 2", false);
        assertEquals(2, logger.getNumberOfLogs());
    }
}
