package uta.cse.cse3310.webchat;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;
import org.java_websocket.WebSocket;
import org.mockito.Mockito;
import org.junit.jupiter.api.Test;

public class UserListTest {
    private UserList userList;
    private WebSocket webSocketMock;

    @BeforeEach
    public void setup() {
        userList = new UserList();
        webSocketMock = Mockito.mock(WebSocket.class);
    }

    @Test
    public void testAdd() {
        userList = new UserList();
        webSocketMock = Mockito.mock(WebSocket.class);
        User user = new User("Alice", webSocketMock);
        userList.add(user);
        assertEquals(1, userList.size());
        assertEquals(user, userList.get(0));
    }

    @Test
    public void testInsertNameForConn() {
        userList.InsertNameForConn(webSocketMock, "Alice");
        assertEquals("Alice", userList.conn2name(webSocketMock));
    }

    @Test
    public void testConn2Name() {
        User user = new User("Alice", webSocketMock);
        userList.add(user);
        String name = userList.conn2name(webSocketMock);
        assertEquals("Alice", name);
    }
}
