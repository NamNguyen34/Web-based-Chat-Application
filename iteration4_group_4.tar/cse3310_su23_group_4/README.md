
The executable is not named as described by the assignment.
For now, it will work.


mvn clean
mvn compile
mvn package
mvn exec:java -Dexec.mainClass=uta.cse.cse3310.webchat.WebChat
