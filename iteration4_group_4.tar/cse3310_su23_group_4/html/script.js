var socket = new WebSocket("ws://cse3310.org:8087/");

window.addEventListener("beforeunload", function() {
    socket.close();
});

socket.onopen = function () {
    console.log("Connected to server");
};

socket.onmessage = function (event) {
    console.log("Received message: " + event.data);
    // if (event.data.startsWith("ID: ")) {

    const json = event.data

    try {
        const jsonObject = JSON.parse(json);

        if ('Users' in jsonObject && 'Chatrooms' in jsonObject) {
            // two lists, one for Users and the other for chatrooms
            displayJsonArray(jsonObject, 'output');
        }
        else if ("From" in jsonObject) {
            var recvChatDiv = document.getElementById("recvChat");
            var u = document.getElementById("recvText");
            var IsMe = jsonObject?.IsMe ?? false;
            var alignment = IsMe ? "right" : "left";
            var sender = IsMe ? "You" : jsonObject.From;

            var messageDiv = document.createElement('div');
            messageDiv.style = `text-align: ${alignment}; padding: 10px; border: 1px solid #ddd; border-radius: 5px; margin: 5px 0;`;
            messageDiv.innerHTML = `${IsMe ? "" : "<strong>" + sender + ":</strong> <br>"}${jsonObject.Text}`;
            messageDiv.classList.add('blinking');

            u.appendChild(messageDiv);

            // Remove blinking effect after 2 seconds
            setTimeout(() => {
                messageDiv.classList.remove('blinking');
            }, 2000);

            // Scroll to the bottom
            recvChatDiv.scrollTop = recvChatDiv.scrollHeight;

        }
        else if ("Type" in jsonObject) {
            if (jsonObject.Type === "Alert") {
                alert(jsonObject.Text);
            }
        }
        else {
            console.log('input not processed' + json);
        }

    } catch (error) {
        console.log('Invalid JSON:', error);
    }
};

socket.onclose = function (event) {
    console.log("Connection closed");
};

function sendMessage() {
    var message = document.getElementById("message").value;
    socket.send(message);
}

class LoginMessage {
    Type = "Login";
    Name = "";
}

function submitName() {
    console.log("the submit name has been pressed");
    var U = new LoginMessage();
    U.Name = document.getElementById("clientname").value;
    console.log("I am here and the name is: " + U.Name)
    if (U.Name === "") {
        alert("Please enter a name");
        return;
    }
    socket.send(JSON.stringify(U));
    console.log(JSON.stringify(U))
}

class ChatroomMessage {
    Type = "Chatroom";
    Name = "";
}

function submitChatroom() {
    console.log("the submit chatroom has been pressed");
    var U = new ChatroomMessage();
    U.Name = document.getElementById("chatroomname").value;
    if (U.Name === "") {
        alert("Please enter a chatroom name");
        return;
    }
    socket.send(JSON.stringify(U));
    console.log(JSON.stringify(U))
}

class TextMessage {
    Type = "Text";
    Text = "";
}
class PrivateTextMessage {
    Type = "PrivateText";
    Text = "";
    To = "";
}
class BlockUserMessage {
    Type = "BlockUser";
    Text = "";
}

function submitText() {
    console.log("the submit chatroom has been pressed");
    var U = new TextMessage();
    U.Text = document.getElementById("chattext").value;
    socket.send(JSON.stringify(U));
    console.log(JSON.stringify(U))
}

function privateMessage() {
    console.log("the submit private chat has been pressed");
    var U = new TextMessage();
    U.Text = document.getElementById("private-chat-text").value;
    U.To = document.getElementById("private-chat-user").value;
    socket.send(JSON.stringify(U));
    console.log(JSON.stringify(U))
}

function blockUser() {
    console.log("the block user has been pressed");
    var U = new BlockUserMessage();
    U.Text = document.getElementById("block-user").value;
    socket.send(JSON.stringify(U));
    console.log(JSON.stringify(U))
}

function displayJsonArray(jsonArray, elementId) {
    var output = '';
    output += '<table border="1" cellspacing="0" cellpadding="5" style="margin: 20px 0;">';

    // Check for Users key in the jsonArray
    if (jsonArray.hasOwnProperty('Users')) {
        output += '<tr><th colspan="2">Users</th></tr>';
        // updae the table to include ID as well
        // output += '<tr><th>Name</th><th>TimeBeenActive</th></tr>'; // Table headers
        output += '<tr><th>ID</th><th>Name</th><th>TimeBeenActive</th></tr>'; // Table headers

        jsonArray.Users.forEach(userJson => {
            var user = JSON.parse(userJson);
            output += '<tr>';
            output += '<td>' + user.ID + '</td>';
            output += '<td>' + user.Name + '</td>';
            output += '<td>' + user.TimeBeenActive + '</td>';
            output += '</tr>';
        });
    }

    output += '</table>';

    // Check for Chatrooms key in the jsonArray
    if (jsonArray.hasOwnProperty('Chatrooms')) {
        output += '<table border="1" cellspacing="0" cellpadding="5" style="margin: 20px 0;">';
        output += '<tr><th colspan="2">Chatrooms</th> <th>Number of messages</th></tr>'; // Table headers

        jsonArray.Chatrooms.forEach(chatroom => {
            var chatroomData = JSON.parse(chatroom);
            output += '<tr>';
            output += '<td colspan="2">' + chatroomData.Name + '</td>';
            output += '<td colspan="2">' + chatroomData.NumberOfSentMessages + '</td>';
            output += '</tr>';
        });

        output += '</table>';
    }

    // document.getElementById(elementId).innerHTML = output;
    const element = document.getElementById(elementId);
    const scrollPosition = element.scrollTop;
    element.innerHTML = output;
    element.scrollTop = scrollPosition;
}
